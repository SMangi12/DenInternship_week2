package com.example.internship_week2;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

public class UserRepository {
    private UserDao userDao;
    private LiveData<User> user;

    public UserRepository(Application application) {
        TaskDatabase database = TaskDatabase.getInstance(application);
        userDao = database.userDao();
        user = userDao.getUser();
    }

    public void insert(User user) {
        new InsertUserAsync(userDao).execute(user);
    }

    public LiveData<User> getUser() {
        return user;
    }

    private static class InsertUserAsync extends AsyncTask<User, Void, Void> {
        private UserDao userDao;

        InsertUserAsync(UserDao dao) {
            this.userDao = dao;
        }

        @Override
        protected Void doInBackground(User... users) {
            userDao.insert(users[0]);
            return null;
        }
    }
}

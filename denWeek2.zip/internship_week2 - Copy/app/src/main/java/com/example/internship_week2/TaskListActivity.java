package com.example.internship_week2;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class TaskListActivity extends AppCompatActivity {

    private TaskViewModel taskViewModel;
    private TaskAdapter adapter;
    private TextView greetingTextView, emptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.taskmanager);

        greetingTextView = findViewById(R.id.userGreeting);
        emptyView = findViewById(R.id.emptyView);

        // Greet user by name
        String userName = getIntent().getStringExtra("username");
        if (userName != null && !userName.isEmpty()) {
            greetingTextView.setText("Welcome, " + userName + " 👋");
        }

        // RecyclerView setup
        RecyclerView recyclerView = findViewById(R.id.taskRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter();
        recyclerView.setAdapter(adapter);

        // ViewModel setup
        taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);
        taskViewModel.getAllTasks().observe(this, tasks -> {
            adapter.setTasks(tasks);
            if (tasks.isEmpty()) {
                emptyView.setVisibility(View.VISIBLE);
            } else {
                emptyView.setVisibility(View.GONE);
            }
        });

        // Adapter listener
//        adapter.setOnTaskClickListener(new TaskAdapter.OnTaskClickListener() {
//            @Override
//            public void onDeleteClick(Task task) {
//                taskViewModel.delete(task);
//            }
//
//            @Override
//            public void onMarkDoneClick(Task task, boolean isChecked) {
//                task.setCompleted(isChecked);
//                taskViewModel.update(task);
//            }
//        });
        // inside onCreate:
        adapter.setOnTaskClickListener(new TaskAdapter.OnTaskClickListener() {
            @Override
            public void onDeleteClick(Task task) {
                taskViewModel.delete(task);
            }

            @Override
            public void onMarkDoneClick(Task task, boolean isChecked) {
                task.setCompleted(isChecked);
                taskViewModel.update(task);
            }

            @Override
            public void onEditClick(Task task) {
                Intent intent = new Intent(TaskListActivity.this, AddTaskActivity.class);
                intent.putExtra("isEdit", true);
                intent.putExtra("taskId", task.getId());
                intent.putExtra("title", task.getTitle());
                intent.putExtra("desc", task.getDescription());
                intent.putExtra("date", task.getDate());
                intent.putExtra("priority", task.getPriority());
                intent.putExtra("completed", task.isCompleted());
                startActivity(intent);
            }
        });


        // Floating button to add new task
        FloatingActionButton addTaskFab = findViewById(R.id.addTaskButton);
        addTaskFab.setOnClickListener(v -> {
            Intent intent = new Intent(TaskListActivity.this, AddTaskActivity.class);
            startActivity(intent);
        });
    }
}

package com.example.internship_week2;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
public class AddTaskActivity extends AppCompatActivity {
    private EditText taskNameEditText, dueDateEditText,taskDesc,taskCateg;
    TextView addNew;
    private CheckBox priorityCheckBox;
    private Button saveButton;
    private Calendar calendar;
    private TaskViewModel taskViewModel;
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.addtask);
    addNew = findViewById(R.id.titleAddNew);
    taskDesc = findViewById(R.id.taskDesc);
    taskNameEditText = findViewById(R.id.taskNameEditText);
    dueDateEditText = findViewById(R.id.dueDateEditText);
    priorityCheckBox = findViewById(R.id.priorityCheckBox);
    saveButton = findViewById(R.id.saveButton);
    taskCateg=findViewById(R.id.taskCategory);
    calendar = Calendar.getInstance();
    taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);
    Intent intent = getIntent();
    boolean isEdit = intent.getBooleanExtra("isEdit", false);
    int taskId = intent.getIntExtra("taskId", -1);

    if (isEdit) {
        addNew.setText("Edit Task");
        taskNameEditText.setText(intent.getStringExtra("title"));
        taskDesc.setText(intent.getStringExtra("desc"));
        taskCateg.setText(intent.getStringExtra("category"));
        dueDateEditText.setText(intent.getStringExtra("date"));
        priorityCheckBox.setChecked("high".equalsIgnoreCase(intent.getStringExtra("priority")));
    }

    dueDateEditText.setOnClickListener(v -> {
        new DatePickerDialog(AddTaskActivity.this, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    });

    saveButton.setOnClickListener(v -> {
        String taskName = taskNameEditText.getText().toString().trim();
        String taskDescr = taskDesc.getText().toString().trim();
        String taskcate= taskCateg.getText().toString().trim();
        String dueDate = dueDateEditText.getText().toString().trim();
        boolean isHighPriority = priorityCheckBox.isChecked();
        String taskPrior = isHighPriority ? "high" : "low";

        if (taskName.isEmpty() || dueDate.isEmpty()) {
            Toast.makeText(this, "Please enter task name and due date.", Toast.LENGTH_SHORT).show();
            return;
        }

        Task task = new Task(taskName, taskDescr, dueDate, taskPrior, false,taskcate);

        if (isEdit) {
            task.setId(taskId);
            task.setCompleted(intent.getBooleanExtra("completed", false));
            taskViewModel.update(task);
            Toast.makeText(this, "Task updated!", Toast.LENGTH_SHORT).show();
        } else {
            taskViewModel.insert(task);
            Toast.makeText(this, "Task added!", Toast.LENGTH_SHORT).show();
        }

        finish();
    });
}

    private final DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, dayOfMonth) -> {
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        dueDateEditText.setText(sdf.format(calendar.getTime()));
    };

}
